extends Sprite2D
var scene = load("res://objects/ball.tscn")
func _process(delta):
	rotation += (PI * 2) * delta
	Globals.launcher_rotation = rotation
	Globals.launcher_x = position.x
	Globals.launcher_y = position.y
	if Input.is_action_pressed("ball_spawn") and $Timer.time_left <= 0.8:
		var instance = scene.instantiate()
		get_tree().current_scene.add_child(instance)
		$Timer.start()
		$boing.play()
	if Input.is_action_pressed("teleport") and Globals.mostrecentball_x != 0 and Globals.mostrecentball_x != position.x:
		global_position = Vector2(Globals.mostrecentball_x, Globals.mostrecentball_y)
		$boing.play()

	
