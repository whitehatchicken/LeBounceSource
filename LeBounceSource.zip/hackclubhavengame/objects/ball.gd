extends RigidBody2D
var frozen = 0
var transmit = 0
var rot = Globals.launcher_rotation

func _ready():
	global_position = Vector2(Globals.launcher_x, Globals.launcher_y)
	
func _physics_process(delta):
	apply_central_impulse(Vector2(cos(rot - PI/2), sin(rot - PI/2)) * 100)
	if frozen == 1:
		freeze = true
		if transmit == 0:
			Globals.mostrecentball_x = position.x
			Globals.mostrecentball_y = position.y
			transmit = 1
		
	if Input.is_action_pressed("reset"):
		queue_free()
	if Input.is_action_pressed("teleport"):
		if position.x == Globals.mostrecentball_x and position.y == Globals.mostrecentball_y:
			queue_free()
		
func _on_body_entered(body):
	frozen = 1

	
