extends Button

func _on_pressed() -> void:
	get_tree().change_scene_to_file("res://levels/Outside-2/Outside-2.tscn")
