extends Button



func _on_pressed() -> void:
	$boing.play()
	get_tree().change_scene_to_file("res://menus/level_select.tscn")
