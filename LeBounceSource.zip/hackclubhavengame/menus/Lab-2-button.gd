extends Button




func _on_pressed() -> void:
	get_tree().change_scene_to_file("res://levels/Lab-2/Lab-2.tscn")
