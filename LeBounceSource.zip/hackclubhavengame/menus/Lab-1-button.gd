extends Button




func _on_pressed() -> void:
	get_tree().change_scene_to_file("res://levels/Lab-1/Lab-1.tscn")
