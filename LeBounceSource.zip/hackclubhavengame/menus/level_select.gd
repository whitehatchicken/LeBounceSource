extends Node2D

func _ready() -> void:
	$boing.play()
	Globals.completed = 0
	$Music.play()
