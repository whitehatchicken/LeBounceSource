extends Label


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	hide()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Globals.completed == 1:
		show()



func _on_next_pressed() -> void:
	get_tree().change_scene_to_file("res://levels/Lab-1/Lab-1.tscn")
	Globals.completed = 0

func _on_backtoselect_pressed() -> void:
	get_tree().change_scene_to_file("res://menus/level_select.tscn")
