extends RigidBody2D

func _ready():
	freeze = true



func _on_button_2_pressed() -> void:
	$boing.play()
	freeze = false
