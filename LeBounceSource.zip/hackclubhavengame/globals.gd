extends Node

var launcher_rotation: float = 0
var launcher_x: float = 0
var launcher_y: float = 0
var mostrecentball_x: float = 0
var mostrecentball_y: float = 0
var completed: float = 0

func _process(delta: float) -> void:
	if completed == 1:
		mostrecentball_x = 0
		mostrecentball_y = 0
